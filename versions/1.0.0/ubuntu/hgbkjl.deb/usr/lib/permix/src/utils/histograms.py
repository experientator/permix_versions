from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.pyplot as plt
import tkinter as tk
from src.language.manager import localization_manager
from src.utils.calculation_tests import show_error

def prepare_and_draw_mass_histogram(equations_to_plot, target_frame, title_suffix = ""):
    if not equations_to_plot:
        _draw_empty_histogram(target_frame, title_suffix)
        return

    plot_data = {}
    equation_labels = []
    all_salts = set()

    for i, eq_data in enumerate(equations_to_plot):
        eq_num = eq_data.get('eq_key_numeric', i + 1)
        equation_labels.append(f"Eq.{eq_num}")

        masses = eq_data.get("masses_g_final_k", {})
        for salt, mass in masses.items():
            all_salts.add(salt)
            if salt not in plot_data:
                plot_data[salt] = [0.0] * len(equations_to_plot)

            mass_val = _convert_mass_to_float(mass)
            plot_data[salt][i] = mass_val

    salt_order = sorted(all_salts)
    salt_colors = _get_salt_colors(salt_order)

    tit = localization_manager.tr("ahyst1")
    title = f"{tit} {title_suffix}".strip()
    _draw_histogram(
        target_frame,
        plot_data,
        equation_labels,
        salt_order,
        salt_colors,
        title
    )


def _draw_empty_histogram(target_frame, title_suffix):
    for widget in target_frame.winfo_children():
        widget.destroy()
    tit = localization_manager.tr("ahyst2")
    tk.Label(target_frame, text=f"{tit} {title_suffix}").pack(padx=5, pady=5)


def _convert_mass_to_float(mass_value):
    if mass_value in [None, "ERROR", "N/A"]:
        return 0.0
    try:
        return float(mass_value)
    except (ValueError, TypeError):
        return 0.0


def _get_salt_colors(salts):
    colors = ['red', 'blue', 'green', 'orange', 'purple', 'brown']
    return {salt: colors[i % len(colors)] for i, salt in enumerate(salts)}


def _draw_histogram(target_frame, plot_data, equation_labels, salt_order, salt_colors, title):
    _draw_histogram_generic(
        target_frame=target_frame,
        plot_data=plot_data,
        equation_labels=equation_labels,
        salt_order=salt_order,
        salt_colors=salt_colors,
        x_axis_label=localization_manager.tr("ahyst3"),
        y_axis_label=localization_manager.tr("ahyst4"),
        title=title
    )


def _draw_histogram_generic(
        target_frame,
        plot_data,
        equation_labels,
        salt_order,
        salt_colors,
        x_axis_label,
        y_axis_label,
        title,
        single_bar_values=None,
        single_bar_color="cornflowerblue"
):
    for widget in target_frame.winfo_children():
        widget.destroy()

    has_data = False
    if single_bar_values is not None:
        has_data = any(v is not None and v > 1e-9 for v in single_bar_values)
    else:
        has_data = any(
            any(v > 1e-9 for v in values)
            for values in plot_data.values()
        )

    if not has_data:
        tk.Label(target_frame,
                 text= localization_manager.tr("ahyst2")).pack(padx=5, pady=5)
        return

    try:
        fig = plt.Figure(figsize=(10, 6), dpi=100)
        ax = fig.add_subplot(111)

        num_equations = len(equation_labels)
        bar_width = 0.6 if num_equations <= 5 else 0.8

        if single_bar_values is not None:
            values = [v if v is not None else 0.0 for v in single_bar_values]
            ax.bar(equation_labels, values, color=single_bar_color, width=bar_width)
        else:
            bottoms = [0] * num_equations
            for salt in salt_order:
                values = plot_data.get(salt, [0.0] * num_equations)
                ax.bar(
                    equation_labels,
                    values,
                    bottom=bottoms,
                    label=salt,
                    color=salt_colors.get(salt, "grey"),
                    width=bar_width
                )
                bottoms = [b + v for b, v in zip(bottoms, values)]

            if salt_order:
                ax.legend(title=localization_manager.tr("ahyst5"),
                          loc='upper right',
                          bbox_to_anchor=(1.0, 1.0))

        ax.set_ylabel(y_axis_label)
        ax.set_xlabel(x_axis_label)
        ax.set_title(title)
        ax.grid(True, axis='y', linestyle='--', alpha=0.7)

        if num_equations > 5:
            plt.setp(ax.get_xticklabels(), rotation=45, ha='right')

        canvas = FigureCanvasTkAgg(fig, master=target_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=2, pady=2)

    except Exception as e:
        er = localization_manager.tr("ahyst6")
        show_error(f"{er}: {e}")
        tk.Label(target_frame,
                 text=localization_manager.tr("ahyst7"),
                 fg="red").pack(padx=5, pady=5)