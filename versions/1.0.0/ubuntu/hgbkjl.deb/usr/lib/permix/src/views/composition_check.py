import tkinter as tk
from tkinter import ttk

from src.utils.calculation_tests import show_error
from src.default_style import AppStyles
from src.language.manager import localization_manager
from src.controllers.composition_form import CompositionController

class CompositionCheckView(tk.Toplevel):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        localization_manager.register_observer(self)
        self.title(localization_manager.tr("ccv_window_title"))
        self.parent = parent
        self.transient(parent)
        self.grab_set()
        self.configure(bg=AppStyles.BACKGROUND_COLOR)
        self.comp_cont = None
        self.geometry("1200x850")
        self.build_ui()
        self.id_to_ucf = None
        self.not_fav_to_ucf = None

    def build_ui(self):
        main_container = tk.Frame(self, **AppStyles.frame_style())
        main_container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        main_container.columnconfigure(0, weight=2)
        main_container.columnconfigure(1, weight=1)
        main_container.rowconfigure(0, weight=1)

        left_column = tk.Frame(main_container, **AppStyles.frame_style())
        left_column.grid(row=0, column=0, sticky="nsew", padx=(0, 5))
        left_column.columnconfigure(0, weight=1)
        left_column.rowconfigure(0, weight=1)
        left_column.rowconfigure(1, weight=1)

        compositions_frame = tk.LabelFrame(left_column,
                                           text=localization_manager.tr("ccv_comp_frame"),
                                           **AppStyles.labelframe_style())
        compositions_frame.grid(row=0, column=0, sticky="nsew", pady=(0, 5))
        compositions_frame.columnconfigure(0, weight=1)
        compositions_frame.rowconfigure(0, weight=1)

        favorites_frame = tk.LabelFrame(left_column,
                                        text=localization_manager.tr("ccv_fav_frame"),
                                        **AppStyles.labelframe_style())
        favorites_frame.grid(row=1, column=0, sticky="nsew", pady=(5, 0))
        favorites_frame.columnconfigure(0, weight=1)
        favorites_frame.rowconfigure(0, weight=1)

        right_column = tk.Frame(main_container, **AppStyles.frame_style())
        right_column.grid(row=0, column=1, sticky="nsew", padx=(5, 0))
        right_column.columnconfigure(0, weight=1)
        right_column.rowconfigure(0, weight=1)
        right_column.rowconfigure(1, weight=4)

        details_frame = tk.LabelFrame(right_column,
                                      text=localization_manager.tr("ccv_det_frame"),
                                      **AppStyles.labelframe_style())
        details_frame.grid(row=1, column=0, sticky="nsew")
        details_frame.columnconfigure(0, weight=1)
        details_frame.rowconfigure(0, weight=1)

        search_frame = tk.Frame(right_column, **AppStyles.frame_style())
        search_frame.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        search_frame.columnconfigure(0, weight=1)
        search_frame.columnconfigure(1, weight=0)

        tk.Label(search_frame, text="Поиск по имени:", **AppStyles.label_style()).grid(
            row=0, column=0, sticky="w", padx=(0, 5))

        self.search_var = tk.StringVar()
        self.search_entry = tk.Entry(search_frame, textvariable=self.search_var, width=30)
        self.search_entry.grid(row=0, column=1, sticky="ew", padx=(0, 5))

        tk.Button(search_frame, text="Найти",
                  command=self.search_by_name, **AppStyles.button_style()).grid(
            row=0, column=2, padx=(5, 0))

        self.search_entry.bind('<Return>', lambda event: self.search_by_name())

        self.comp_columns = (localization_manager.tr("ccv_comp_col_id"),
                             localization_manager.tr("ccv_comp_col_name"),
                             localization_manager.tr("ccv_comp_col_device_type"),
                             localization_manager.tr("ccv_comp_col_doi"),
                             localization_manager.tr("ccv_comp_col_data"),
                             localization_manager.tr("ccv_comp_col_notes"),
                             localization_manager.tr("ccv_comp_col_template"))

        comp_container = tk.Frame(compositions_frame, **AppStyles.frame_style())
        comp_container.grid(row=0, column=0, sticky="nsew")
        comp_container.columnconfigure(0, weight=1)
        comp_container.rowconfigure(0, weight=1)
        comp_container.rowconfigure(1, weight=0)

        self.comp_tree = ttk.Treeview(comp_container, columns=self.comp_columns,
                                      show='headings', height=8,
                                      **AppStyles.treeview_config())

        for col in self.comp_columns:
            self.comp_tree.heading(col, text=col)
            self.comp_tree.column(col, width=80, stretch=True)

        comp_v_scrollbar = ttk.Scrollbar(comp_container, orient=tk.VERTICAL,
                                         command=self.comp_tree.yview)
        comp_h_scrollbar = ttk.Scrollbar(comp_container, orient=tk.HORIZONTAL,
                                         command=self.comp_tree.xview)

        self.comp_tree.configure(yscrollcommand=comp_v_scrollbar.set,
                                 xscrollcommand=comp_h_scrollbar.set)

        self.comp_tree.grid(row=0, column=0, sticky="nsew")
        comp_v_scrollbar.grid(row=0, column=1, sticky="ns")
        comp_h_scrollbar.grid(row=1, column=0, sticky="ew")

        fav_container = tk.Frame(favorites_frame, **AppStyles.frame_style())
        fav_container.grid(row=0, column=0, sticky="nsew")
        fav_container.columnconfigure(0, weight=1)
        fav_container.rowconfigure(0, weight=1)
        fav_container.rowconfigure(1, weight=0)

        self.fav_columns = (localization_manager.tr("ccv_fav_col_id"),
                            localization_manager.tr("ccv_fav_col_name"),
                            localization_manager.tr("ccv_comp_col_template"),
                            localization_manager.tr("ccv_fav_col_notes"),
                            )

        self.fav_tree = ttk.Treeview(fav_container, columns=self.fav_columns,
                                     show='headings', height=8,
                                     **AppStyles.treeview_config())

        for col in self.fav_columns:
            self.fav_tree.heading(col, text=col)
            self.fav_tree.column(col, width=80, stretch=True)

        fav_v_scrollbar = ttk.Scrollbar(fav_container, orient=tk.VERTICAL,
                                        command=self.fav_tree.yview)
        fav_h_scrollbar = ttk.Scrollbar(fav_container, orient=tk.HORIZONTAL,
                                        command=self.fav_tree.xview)

        self.fav_tree.configure(yscrollcommand=fav_v_scrollbar.set,
                                xscrollcommand=fav_h_scrollbar.set)

        self.fav_tree.grid(row=0, column=0, sticky="nsew")
        fav_v_scrollbar.grid(row=0, column=1, sticky="ns")
        fav_h_scrollbar.grid(row=1, column=0, sticky="ew")

        details_container = tk.Frame(details_frame, **AppStyles.frame_style())
        details_container.grid(row=0, column=0, sticky="nsew")
        details_container.columnconfigure(0, weight=1)
        details_container.rowconfigure(0, weight=1)

        self.notebook = ttk.Notebook(details_container)
        self.notebook.grid(row=0, column=0, sticky="nsew")

        self.main_tab = tk.Frame(self.notebook, **AppStyles.frame_style())
        self.solvents_tab = tk.Frame(self.notebook, **AppStyles.frame_style())
        self.structure_tab = tk.Frame(self.notebook, **AppStyles.frame_style())
        self.synthesis_tab = tk.Frame(self.notebook, **AppStyles.frame_style())
        self.properties_tab = tk.Frame(self.notebook, **AppStyles.frame_style())
        self.kfactors_tab = tk.Frame(self.notebook, **AppStyles.frame_style())

        self.notebook.add(self.main_tab, text=localization_manager.tr("ccv_main_tab"))
        self.notebook.add(self.solvents_tab, text=localization_manager.tr("ccv_solvents_tab"))
        self.notebook.add(self.structure_tab, text=localization_manager.tr("ccv_structure_tab"))
        self.notebook.add(self.synthesis_tab, text=localization_manager.tr("ccv_synthesis_tab"))
        self.notebook.add(self.properties_tab, text=localization_manager.tr("ccv_properties_tab"))
        self.notebook.add(self.kfactors_tab, text=localization_manager.tr("ccv_kfactors_tab"))

        control_frame = tk.Frame(main_container, **AppStyles.frame_style())
        control_frame.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(10, 0))

        control_frame.columnconfigure(0, weight=1)
        control_frame.columnconfigure(1, weight=0)
        control_frame.columnconfigure(2, weight=1)

        tk.Button(control_frame,
                  text=localization_manager.tr("ccv_upload_but"),
                  command=self.return_to_main,
                  **AppStyles.button_style()).grid(row=0, column=3, padx=5, pady=5, sticky='ew')
        tk.Button(control_frame,
                  text=localization_manager.tr("ccv_upload_structure_but"),
                  command=self.open_comp_form,
                  **AppStyles.button_style()).grid(row=0, column=2, padx=5, pady=5, sticky='ew')
        tk.Button(control_frame,
                  text=localization_manager.tr("ccv_del_sel_but"),
                  command=self.delete_selected,
                  **AppStyles.button_style()).grid(row=0, column=1, padx=5, pady=5, sticky='ew')
        tk.Button(control_frame,
                  text=localization_manager.tr("ccv_edit_comp_but"),
                  command=self.update_composition,
                  **AppStyles.button_style()).grid(row=0, column=0, padx=5, pady=5, sticky='ew')

        self.comp_tree.bind('<<TreeviewSelect>>', self.on_composition_select)
        self.fav_tree.bind('<<TreeviewSelect>>', self.on_favorite_select)

    def open_comp_form(self):
        CompositionController(self)

    def on_composition_select(self, event):
        selection = self.comp_tree.selection()
        if selection:
            self.fav_tree.selection_remove(self.fav_tree.selection())

            item = self.comp_tree.item(selection[0])
            composition_id = item['values'][0]
            self.id_to_ucf = composition_id
            self.not_fav_to_ucf = True
            self.controller.load_composition_details(composition_id)

    def on_favorite_select(self, event):
        selection = self.fav_tree.selection()
        if selection:
            self.comp_tree.selection_remove(self.comp_tree.selection())

            item = self.fav_tree.item(selection[0])
            favorite_id = item['values'][0]
            self.id_to_ucf = favorite_id
            self.not_fav_to_ucf = False
            self.controller.load_favorite_details(favorite_id)

    def display_compositions(self, data):
        self.comp_tree.delete(*self.comp_tree.get_children())
        for row in data:
            self.comp_tree.insert('', 'end', values=row)

    def display_favorites(self, data):
        self.fav_tree.delete(*self.fav_tree.get_children())
        for row in data:
            self.fav_tree.insert('', 'end', values=row)

    def display_details(self, details, is_favorite=False):
        self.clear_tabs()

        if details:
            self.display_main_info(details['main_info'], is_favorite)
            self.display_solvents(details['solvents'])
            self.display_structure(details['structure'])
            self.display_synthesis(details['synthesis'], is_favorite)

            if not is_favorite and details.get('properties'):
                self.display_properties(details['properties'], details['device_type'])

            self.display_k_factors(details['k_factors'])

    def display_main_info(self, main_info, is_favorite):
        if main_info:
            for widget in self.main_tab.winfo_children():
                widget.destroy()

            main_frame = tk.Frame(self.main_tab, **AppStyles.frame_style())
            main_frame.pack(fill=tk.BOTH, expand=True)

            canvas = tk.Canvas(main_frame, bg=AppStyles.BACKGROUND_COLOR, highlightthickness=0)
            scrollbar = ttk.Scrollbar(main_frame, orient=tk.VERTICAL, command=canvas.yview)
            scrollable_frame = tk.Frame(canvas, **AppStyles.frame_style())

            scrollable_frame.bind(
                "<Configure>",
                lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
            )

            canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
            canvas.configure(yscrollcommand=scrollbar.set)

            canvas.pack(side="left", fill="both", expand=True, padx=5, pady=5)
            scrollbar.pack(side="right", fill="y")

            if is_favorite:
                labels = self.fav_columns
            else:
                labels = [
                    localization_manager.tr("ccv_comp_col_id"),
                    localization_manager.tr("ccv_comp_col_template"),
                    localization_manager.tr("ccv_comp_col_device_type"),
                    localization_manager.tr("ccv_comp_col_name"),
                    localization_manager.tr("ccv_comp_col_doi"),
                    localization_manager.tr("ccv_comp_col_data"),
                    localization_manager.tr("ccv_comp_col_notes")
                ]

            for i, (label, value) in enumerate(zip(labels, main_info)):
                label_widget = tk.Label(scrollable_frame, text=f"{label}:",
                                        anchor=tk.W, **AppStyles.label_style())
                label_widget.grid(row=i, column=0, sticky="w", padx=2, pady=1)

                value_widget = tk.Label(scrollable_frame, text=str(value) if value else '',
                                        anchor=tk.W, **AppStyles.label_style())
                value_widget.grid(row=i, column=1, sticky="w", padx=2, pady=1)

    def display_solvents(self, solvents):
        for widget in self.solvents_tab.winfo_children():
            widget.destroy()

        if solvents:
            columns = (localization_manager.tr("ccv_solv_col_type"),
                       localization_manager.tr("ccv_solv_col_symbol"),
                       localization_manager.tr("ccv_solv_col_fraction"))
            tree = self.create_treeview(self.solvents_tab, columns)
            for solvent in solvents:
                tree.insert('', 'end', values=solvent)
        else:
            tk.Label(self.solvents_tab,
                     text=localization_manager.tr("ccv_no_solv_data"),
                     **AppStyles.label_style()).pack(expand=True)
    def display_structure(self, structure):
        for widget in self.structure_tab.winfo_children():
            widget.destroy()

        if structure:
            columns = (localization_manager.tr("ccv_struct_col_type"),
                       localization_manager.tr("ccv_struct_col_symbol"),
                       localization_manager.tr("ccv_struct_col_fraction"),
                       localization_manager.tr("ccv_struct_col_val"))
            tree = self.create_treeview(self.structure_tab, columns)
            for element in structure:
                tree.insert('', 'end', values=element)
        else:
            tk.Label(self.structure_tab,
                     text=localization_manager.tr("ccv_no_struct_data"),
                     **AppStyles.label_style()).pack(expand=True)

    def display_synthesis(self, synthesis, is_favorite):
        for widget in self.synthesis_tab.winfo_children():
            widget.destroy()
        main_frame = tk.Frame(self.synthesis_tab, **AppStyles.frame_style())
        main_frame.pack(fill=tk.BOTH, expand=True)

        canvas = tk.Canvas(main_frame, bg=AppStyles.BACKGROUND_COLOR, highlightthickness=0)
        scrollbar = ttk.Scrollbar(main_frame, orient=tk.VERTICAL, command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, **AppStyles.frame_style())

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )

        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True, padx=5, pady=5)
        scrollbar.pack(side="right", fill="y")

        if is_favorite:
            labels = [
                localization_manager.tr("ccv_prop_col_v_antisol"),
                localization_manager.tr("ccv_prop_col_v_sol"),
                localization_manager.tr("ccv_prop_col_conc")
            ]
            for i, (label, value) in enumerate(zip(labels, synthesis)):
                label_widget = tk.Label(scrollable_frame, text=f"{label}:",
                                        anchor=tk.W, **AppStyles.label_style())
                label_widget.grid(row=i, column=0, sticky="w", padx=2, pady=1)

                value_widget = tk.Label(scrollable_frame, text=str(value) if value else '',
                                        anchor=tk.W, **AppStyles.label_style())
                value_widget.grid(row=i, column=1, sticky="w", padx=2, pady=1)

        else:
            labels = [
                localization_manager.tr("ccv_prop_col_stab_notes"),
                localization_manager.tr("ccv_prop_col_v_antisol"),
                localization_manager.tr("ccv_prop_col_v_sol"),
                localization_manager.tr("ccv_prop_col_conc"),
                localization_manager.tr("ccv_prop_col_method")
            ]
            for i, (label, value) in enumerate(zip(labels, synthesis[1:])):
                label_widget = tk.Label(scrollable_frame, text=f"{label}:",
                                            anchor=tk.W, **AppStyles.label_style())
                label_widget.grid(row=i, column=0, sticky="w", padx=2, pady=1)

                value_widget = tk.Label(scrollable_frame, text=str(value) if value else '',
                                            anchor=tk.W, **AppStyles.label_style())
                value_widget.grid(row=i, column=1, sticky="w", padx=2, pady=1)

    def display_properties(self, properties, device_type):
        for widget in self.properties_tab.winfo_children():
            widget.destroy()

        if properties:
            main_frame = tk.Frame(self.properties_tab, **AppStyles.frame_style())
            main_frame.pack(fill=tk.BOTH, expand=True)

            canvas = tk.Canvas(main_frame, bg=AppStyles.BACKGROUND_COLOR, highlightthickness=0)
            scrollbar = ttk.Scrollbar(main_frame, orient=tk.VERTICAL, command=canvas.yview)
            scrollable_frame = tk.Frame(canvas, **AppStyles.frame_style())

            scrollable_frame.bind(
                "<Configure>",
                lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
            )

            canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
            canvas.configure(yscrollcommand=scrollbar.set)

            canvas.pack(side="left", fill="both", expand=True, padx=5, pady=5)
            scrollbar.pack(side="right", fill="y")

            if device_type == localization_manager.tr("ccv_device1"):
                labels = [localization_manager.tr("ccv_dev1_prop1"),
                          localization_manager.tr("ccv_dev1_prop2"),
                          localization_manager.tr("ccv_dev1_prop3"),
                          localization_manager.tr("ccv_dev1_prop4"),
                          localization_manager.tr("ccv_dev1_prop5"),
                          localization_manager.tr("ccv_dev1_prop6"),
                          localization_manager.tr("ccv_dev1_prop7")]

            elif device_type == localization_manager.tr("ccv_device2"):
                labels = [localization_manager.tr("ccv_dev2_prop1"),
                          localization_manager.tr("ccv_dev2_prop2"),
                          localization_manager.tr("ccv_dev2_prop3"),
                          localization_manager.tr("ccv_dev2_prop4"),
                          localization_manager.tr("ccv_dev2_prop5"),
                          localization_manager.tr("ccv_dev2_prop6"),
                          localization_manager.tr("ccv_dev2_prop7")]

            elif device_type == localization_manager.tr("ccv_device3"):
                labels = [localization_manager.tr("ccv_dev3_prop1"),
                          localization_manager.tr("ccv_dev3_prop2"),
                          localization_manager.tr("ccv_dev3_prop3"),
                          localization_manager.tr("ccv_dev3_prop4"),
                          localization_manager.tr("ccv_dev3_prop5"),
                          localization_manager.tr("ccv_dev3_prop6"),
                          localization_manager.tr("ccv_dev3_prop7")]

            elif device_type == localization_manager.tr("ccv_device4"):
                labels = [localization_manager.tr("ccv_dev4_prop1"),
                          localization_manager.tr("ccv_dev4_prop2"),
                          localization_manager.tr("ccv_dev4_prop3"),
                          localization_manager.tr("ccv_dev4_prop4"),
                          localization_manager.tr("ccv_dev4_prop5")]

            elif device_type == localization_manager.tr("ccv_device5"):
                labels = [localization_manager.tr("ccv_dev5_prop1"),
                          localization_manager.tr("ccv_dev5_prop2"),
                          localization_manager.tr("ccv_dev5_prop3"),
                          localization_manager.tr("ccv_dev5_prop4"),
                          localization_manager.tr("ccv_dev5_prop5"),
                          localization_manager.tr("ccv_dev5_prop6"),
                          localization_manager.tr("ccv_dev5_prop7")]

            elif device_type == localization_manager.tr("ccv_device6"):
                labels = [localization_manager.tr("ccv_dev6_prop1"),
                          localization_manager.tr("ccv_dev6_prop2"),
                          localization_manager.tr("ccv_dev6_prop3"),
                          localization_manager.tr("ccv_dev6_prop4"),
                          localization_manager.tr("ccv_dev6_prop5"),
                          localization_manager.tr("ccv_dev6_prop6")]

            elif device_type == localization_manager.tr("ccv_device7"):
                labels = [localization_manager.tr("ccv_dev7_prop1"),
                          localization_manager.tr("ccv_dev7_prop2"),
                          localization_manager.tr("ccv_dev7_prop3"),
                          localization_manager.tr("ccv_dev7_prop4")]

            elif device_type == localization_manager.tr("ccv_device8"):
                labels = [localization_manager.tr("ccv_dev8_prop1"),
                          localization_manager.tr("ccv_dev8_prop2"),
                          localization_manager.tr("ccv_dev8_prop3"),
                          localization_manager.tr("ccv_dev8_prop4")]

            elif device_type == localization_manager.tr("ccv_device9"):
                labels = [localization_manager.tr("ccv_dev9_prop1"),
                          localization_manager.tr("ccv_dev9_prop2"),
                          localization_manager.tr("ccv_dev9_prop3"),
                          localization_manager.tr("ccv_dev9_prop4")]
            else:
                labels = [f"Property {i + 1}" for i in range(len(properties))]

            row = 0
            for i, value in enumerate(properties):
                if value is not None:
                    label_widget = tk.Label(scrollable_frame, text=f"{labels[i]}:",
                                            anchor=tk.W, **AppStyles.label_style())
                    label_widget.grid(row=row, column=0, sticky="w", padx=2, pady=1)

                    value_widget = tk.Label(scrollable_frame, text=str(value),
                                            anchor=tk.W, **AppStyles.label_style())
                    value_widget.grid(row=row, column=1, sticky="w", padx=2, pady=1)
                    row += 1
        else:
            tk.Label(self.properties_tab,
                     text=localization_manager.tr("ccv_no_prop_data"),
                     **AppStyles.label_style()).pack(expand=True)

    def display_k_factors(self, k_factors):
        for widget in self.kfactors_tab.winfo_children():
            widget.destroy()

        if k_factors:
            columns = (localization_manager.tr("ccv_k_col_salt"),
                       localization_manager.tr("ccv_k_col_k_fact"))
            tree = self.create_treeview(self.kfactors_tab, columns)
            for factor in k_factors:
                tree.insert('', 'end', values=factor)
        else:
            tk.Label(self.kfactors_tab,
                     text=localization_manager.tr("ccv_no_fact_data"),
                     **AppStyles.label_style()).pack(expand=True)

    def search_by_name(self):
        search_text = self.search_var.get().strip().lower()
        if not search_text:
            show_error(localization_manager.tr("ccv_err_text"))
            return
        self.comp_tree.selection_remove(self.comp_tree.selection())
        self.fav_tree.selection_remove(self.fav_tree.selection())
        self.id_to_ucf = None
        self.not_fav_to_ucf = None

        found_in_comp = False
        found_in_fav = False

        for item in self.comp_tree.get_children():
            values = self.comp_tree.item(item)['values']
            if len(values) > 1 and search_text in str(values[1]).lower():
                self.comp_tree.selection_set(item)
                self.comp_tree.focus(item)
                self.comp_tree.see(item)
                found_in_comp = True
                break

        if not found_in_comp:
            for item in self.fav_tree.get_children():
                values = self.fav_tree.item(item)['values']
                if len(values) > 1 and search_text in str(values[1]).lower():
                    self.fav_tree.selection_set(item)
                    self.fav_tree.focus(item)
                    self.fav_tree.see(item)
                    found_in_fav = True
                    break

        if not found_in_comp and not found_in_fav:
            er1 = localization_manager.tr("ccv_err_name1")
            er2 = localization_manager.tr("ccv_err_name2")
            show_error(f"{er1} '{search_text}' {er2}")
        else:
            if found_in_comp:
                selection = self.comp_tree.selection()
                if selection:
                    item = self.comp_tree.item(selection[0])
                    composition_id = item['values'][0]
                    self.id_to_ucf = composition_id
                    self.not_fav_to_ucf = True
                    self.controller.load_composition_details(composition_id)
            elif found_in_fav:
                selection = self.fav_tree.selection()
                if selection:
                    item = self.fav_tree.item(selection[0])
                    favorite_id = item['values'][0]
                    self.id_to_ucf = favorite_id
                    self.not_fav_to_ucf = False
                    self.controller.load_favorite_details(favorite_id)

    def create_treeview(self, parent, columns):
        container = tk.Frame(parent, **AppStyles.frame_style())
        container.pack(fill=tk.BOTH, expand=True)

        container.columnconfigure(0, weight=1)
        container.rowconfigure(0, weight=1)
        container.rowconfigure(1, weight=0)

        tree = ttk.Treeview(container, columns=columns, show='headings',
                            **AppStyles.treeview_config())

        for col in columns:
            tree.heading(col, text=col)
            tree.column(col, width=100, stretch=True)

        v_scrollbar = ttk.Scrollbar(container, orient=tk.VERTICAL, command=tree.yview)
        h_scrollbar = ttk.Scrollbar(container, orient=tk.HORIZONTAL, command=tree.xview)

        tree.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)

        tree.grid(row=0, column=0, sticky="nsew")
        v_scrollbar.grid(row=0, column=1, sticky="ns")
        h_scrollbar.grid(row=1, column=0, sticky="ew")

        return tree

    def clear_tabs(self):
        for tab in [self.main_tab, self.solvents_tab, self.structure_tab,
                    self.synthesis_tab, self.properties_tab, self.kfactors_tab]:
            for widget in tab.winfo_children():
                widget.destroy()

    def return_to_main(self):
        if self.id_to_ucf:
            id = self.id_to_ucf
            notfav = self.not_fav_to_ucf

            if hasattr(self.parent, 'return_from_composition_check'):
                self.parent.return_from_composition_check(id, notfav)

            self.destroy()
        else:
            show_error(localization_manager.tr("ccv_no_data"))

    def delete_selected(self):
        if self.id_to_ucf:
           self.controller.delete_selected(self.id_to_ucf, self.not_fav_to_ucf)
        else:
            localization_manager.tr("ion_war")

    def get_composition_controller(self):
        if self.comp_cont is None:
            self.comp_cont = CompositionController(self)
        return self.comp_cont

    def update_composition(self):
        if self.id_to_ucf:
            id = self.id_to_ucf
            notfav = self.not_fav_to_ucf

            comp_cont = self.get_composition_controller()

            if hasattr(comp_cont, 'update_composition'):
                comp_cont.update_composition(id, notfav)