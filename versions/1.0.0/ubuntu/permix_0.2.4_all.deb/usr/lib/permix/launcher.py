#!/usr/bin/env python3
import os
import sys
import shutil
import traceback

def setup_environment():
    """Setup environment with proper database path"""
    # Use home directory for compatibility
    data_dir = os.path.expanduser("~/.permix")
    os.makedirs(data_dir, exist_ok=True)

    # Copy database if needed
    system_db = "/usr/lib/permix/data.db"
    user_db = os.path.join(data_dir, "data.db")

    if not os.path.exists(user_db):
        try:
            shutil.copy2(system_db, user_db)
            print(f"Database copied to: {user_db}")
        except Exception as e:
            print(f"Error copying database: {e}")
            user_db = system_db  # Fallback

    # Set environment variable
    os.environ["PERMIX_DATABASE_PATH"] = user_db
    print(f"Using database: {user_db}")
    return user_db

if __name__ == "__main__":
    # Setup environment
    db_path = setup_environment()

    # Add to Python path
    sys.path.insert(0, "/usr/lib/permix")

    try:
        # Import and explicitly run the application
        from main import App, init_database

        # Initialize database and start GUI
        init_database()
        app = App()
        app.mainloop()

    except Exception as e:
        print(f"Error: {e}")
        traceback.print_exc()
        input("Press Enter to exit...")
